from django.urls import path

from . import views

urlpatterns = [
    # ex: /polls/
   path('', views.home, name = "home"),
   path('myapp/user_login', views.login_user, name = "user_login"),
   path("thanks/",views.thanks, name="thanks"),
   
]