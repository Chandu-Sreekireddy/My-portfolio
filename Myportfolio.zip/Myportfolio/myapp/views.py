from django.shortcuts import render
from django.contrib.auth import authenticate,login,logout
from django.shortcuts import render,redirect
from django.contrib.auth import login,authenticate
from django.contrib.auth.models import User
from django.contrib import auth
from django.views.generic import CreateView
from .models import Contact
from django.urls import reverse_lazy
from django.http import HttpResponse
# Create your views here.



def home(request):
    return render(request,"base.html")


def index(request):
    return render(request,"index.html")



def login_user(request):
    if request.method == "POST":
        user = auth.authenticate(username=request.POST['username'], password=request.POST['password'])
        if user is not None:
            auth.login(request, user)
            return render(request,'index.html')
        else:
            return render(request,"base.html",{'error':'Username or password is incorrect!'})

    else:
        return render(request,"base.html")    
           
       

class ContactCreate(CreateView):
    model = Contact
    fields = ["first_name", "last_name", "message"]
    success_url = reverse_lazy("thanks")





def thanks(request):
    return HttpResponse("Thank you! Will get in touch soon.")